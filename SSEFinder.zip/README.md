# SSEFinder
Group Project for COMP3297 by Group R

### All required functionality has been implemented. 

### Assumptions
- Data is entered properly otherwise error is displayed. 
- Case numbers are unique 


